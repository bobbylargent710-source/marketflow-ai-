const $=id=>document.getElementById(id);
let products=JSON.parse(localStorage.getItem('sb_products')||'[]');
let orders=JSON.parse(localStorage.getItem('sb_orders')||'[]');
let settings=JSON.parse(localStorage.getItem('sb_settings')||'{"name":"Smart Biz Store","currency":"FCFA","whatsapp":""}');
function money(n){return Number(n||0).toLocaleString('fr-FR')+' '+settings.currency}
function persist(){localStorage.setItem('sb_products',JSON.stringify(products));localStorage.setItem('sb_orders',JSON.stringify(orders));render()}
function render(){
 $('productsCount').textContent=products.length;$('ordersCount').textContent=orders.length;
 $('revenue').textContent=money(orders.reduce((s,o)=>s+o.total,0));
 $('customersCount').textContent=new Set(orders.map(o=>o.customer)).size;$('navOrders').textContent=orders.length;
 $('productRows').innerHTML=products.map((p,i)=>`<tr><td><div class="product-cell"><img class="thumb" src="${safe(p.image)||'https://placehold.co/80x80/f0edff/6855dc?text=SB'}"><b>${safe(p.name)}</b></div></td><td>${money(p.price)}</td><td>${p.stock}</td><td><span class="status">Actif</span></td><td><button class="secondary" onclick="deleteProduct(${i})">Supprimer</button></td></tr>`).join('');
 $('noProducts').style.display=products.length?'none':'block';
 $('storeProducts').innerHTML=products.map((p,i)=>`<article class="store-card"><img src="${safe(p.image)||'https://placehold.co/400x250/f0edff/6855dc?text=Smart+Biz'}"><div><b>${safe(p.name)}</b><strong>${money(p.price)}</strong><p>${safe(p.description||'Disponible dans notre boutique.')}</p><button onclick="buyProduct(${i})">Commander</button></div></article>`).join('')||'<div class="empty">Ajoutez des produits pour voir votre boutique.</div>';
 $('orderRows').innerHTML=orders.map(o=>`<tr><td><b>${o.id}</b></td><td>${safe(o.customer)}</td><td>${money(o.total)}</td><td>${o.date}</td><td><span class="status">${o.status}</span></td></tr>`).join('');
 $('noOrders').style.display=orders.length?'none':'block';
 $('recentOrders').innerHTML=orders.slice(-4).reverse().map(o=>`<p style="padding:10px;border-bottom:1px solid #eee"><b>${o.id}</b> — ${safe(o.customer)} <span style="float:right">${money(o.total)}</span></p>`).join('')||'Aucune commande pour le moment.<br><small>Les nouvelles commandes apparaîtront ici.</small>';
 $('customerList').innerHTML=[...new Set(orders.map(o=>o.customer))].map(n=>`<p style="padding:12px;border-bottom:1px solid #eee">♙ &nbsp; ${safe(n)}</p>`).join('')||'Vos clients apparaîtront ici après leur première commande.';
 $('shopName').value=settings.name;$('currency').value=settings.currency;$('whatsapp').value=settings.whatsapp;
}
function safe(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function openProductModal(){$('modal').classList.remove('hidden')}
function closeModal(){$('modal').classList.add('hidden')}
$('productForm').addEventListener('submit',e=>{e.preventDefault();products.push({name:$('pName').value,price:Number($('pPrice').value),stock:Number($('pStock').value),image:$('pImage').value,description:$('pDescription').value});e.target.reset();closeModal();persist()});
function deleteProduct(i){if(confirm('Supprimer ce produit ?')){products.splice(i,1);persist()}}
function buyProduct(i){const p=products[i],customer=prompt('Votre nom pour la commande :');if(!customer)return;orders.push({id:'SB-'+String(Date.now()).slice(-6),customer,total:p.price,date:new Date().toLocaleDateString('fr-FR'),status:'À traiter'});persist();alert('Commande enregistrée ! Le paiement en ligne doit être configuré avant la mise en production.')}
function saveSettings(){settings={name:$('shopName').value,currency:$('currency').value,whatsapp:$('whatsapp').value};localStorage.setItem('sb_settings',JSON.stringify(settings));$('saved').textContent='Paramètres enregistrés.';render()}
function navigate(){let id=location.hash.slice(1)||'dashboard';document.querySelectorAll('.view').forEach(v=>v.classList.toggle('hidden',v.id!==id));document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+id));const titles={dashboard:'Tableau de bord',products:'Produits',orders:'Commandes',customers:'Clients',store:'Ma boutique',settings:'Paramètres'};$('pageTitle').textContent=titles[id]||'Tableau de bord'}
window.addEventListener('hashchange',navigate);navigate();render();
