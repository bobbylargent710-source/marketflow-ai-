# Smart Biz — prototype e-commerce

## Lancer
Ouvrez `index.html` dans un navigateur récent. Aucun serveur ni installation n'est nécessaire.

## Inclus
- Tableau de bord avec chiffre d'affaires, commandes, produits et clients
- Ajout/suppression de produits
- Aperçu de la boutique et commande de démonstration
- Liste des commandes et des clients
- Paramètres de boutique et devise
- Données de démonstration persistées dans le stockage local du navigateur

## À faire avant une vraie mise en production
Ce paquet est un prototype front-end, pas encore un SaaS multi-utilisateur sécurisé.
Il faut notamment ajouter une API/backend, une base de données, authentification,
gestion des rôles, stockage d'images, validation serveur, sauvegardes, emails,
journalisation et intégration de paiement (par exemple Mobile Money selon le pays
et le prestataire choisi). Les commandes de cette version ne déclenchent aucun
paiement réel et les données restent sur l'appareil utilisé.
